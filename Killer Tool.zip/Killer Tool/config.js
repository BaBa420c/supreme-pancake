module.exports = {
    numberOfRegisterInOneTime: 6, // no of registration want to make in one command.
    domains: ["example.com", "example.com"], // names of domain for the emails. 
    oneTimeMailGen: 10 * 100000,
    telegramBotToken: "TOKEN_HERE", // bot token of telegram bot. Create a bot using https://t.me/BotFather then generate the token of the bot.
    adminNamesForTelegramBot: ["sigma","mariana_web"], // name of the admin/developer who's name will be displayed when any unknown user use the command of the bot in telegram.
    authorisedUserForTelegramBot: ["mariana_web","mariana_web"] // username or id of the user who can use the bot.
};